# RGNODES™ Status Panel

A responsive black/violet hosting status page with a separate admin console, real server-side HTTP/HTTPS, TCP-port and ICMP ping checks, recorded uptime, latency, outage/recovery events, configurable branding, and a one-command VPS installer. It uses Node.js built-ins only; there are no npm runtime dependencies or external database service requirements.

## Project files

```text
RGNODES-Status-Panel/
├── database.js             # Atomic JSON storage + JSONL sample history
├── index.js                # Web server, secure admin API, ping/check scheduler
├── .env                    # Private configuration; setup generates strong credentials
├── .env.example            # Safe configuration template
├── package.json            # Start and syntax-check scripts
├── ssetup.sh               # VPS installer + 24/7 service setup
├── README.md
├── dashbord/
│   ├── user.html            # Public status page
│   └── admin.html           # Admin login + monitor management
├── public/assets/logo.svg   # Default animated logo; replaceable by GIF/SVG/WebP/PNG
└── data/                    # Generated target, incident and history data
```

## One-command VPS setup

Recommended: Ubuntu/Debian or another Linux VPS using `systemd`. Node.js 20+ is required; the installer installs Node.js 22 if necessary on supported package-managed systems. For ICMP monitoring it also installs the OS `ping` utility when possible.

1. Upload and extract the ZIP on the VPS.
2. Enter the extracted project directory and run:

```bash
chmod +x ssetup.sh
sudo ./ssetup.sh
```

The installer checks the required files, prepares `/opt/rgnodes-status`, generates a strong admin password and session secret when placeholders are present, initializes persistent storage, checks JavaScript syntax, installs a `systemd` service, enables it at boot, starts it, and verifies the local API health endpoint. The service automatically restarts after unexpected exits. A cron/watchdog fallback is attempted when `systemd` is unavailable.

The default port is **2201**, separate from a Discord bot process. Ensure that port is available and that your firewall or reverse proxy permits access. The script prints the public-page URL, admin URL, username and generated password after successful setup.

```text
Public page: http://YOUR_VPS_IP:2201/
Admin page:  http://YOUR_VPS_IP:2201/admin
```

Keep `.env` private. Use HTTPS via Nginx/Caddy before exposing the admin login to the internet. Useful systemd commands:

```bash
sudo systemctl status rgnodes-status
sudo journalctl -u rgnodes-status -f
sudo systemctl restart rgnodes-status
```

## Settings in `.env`

```dotenv
HOST=0.0.0.0
PORT=2201
SITE_NAME=RGNODES™ Status
COMPANY_NAME=RGNODES™
LOGO_URL=/assets/logo.svg
ADMIN_PATH=/admin
AUTO_REFRESH_SECONDS=60
DEFAULT_PING_SECONDS=5
REQUEST_TIMEOUT_MS=8000
AUTO_OPTIMIZE_INTERVAL_SECONDS=60
MAX_CONCURRENT_CHECKS=10
ADMIN_USERNAME=admin
ADMIN_PASSWORD=generated-by-ssetup
SESSION_SECRET=generated-by-ssetup
```

- `SITE_NAME` and `COMPANY_NAME`: public branding.
- `LOGO_URL`: a local `/assets/...` file or HTTPS URL. Animated GIF and animated SVG logos are supported by browsers; WebP animation depends on browser support.
- `ADMIN_PATH`: admin URL path; default `/admin`.
- `AUTO_REFRESH_SECONDS`: browser refresh interval, default 60 seconds.
- `DEFAULT_PING_SECONDS`: initial interval for a new monitor, default 5 seconds.
- `AUTO_OPTIMIZE_INTERVAL_SECONDS`: housekeeping/history-compaction interval, default 60 seconds.
- `REQUEST_TIMEOUT_MS`: upper bound for an HTTP/TCP/ICMP attempt, default 8 seconds.
- `MAX_CONCURRENT_CHECKS`: concurrency cap, default 10.

After editing `.env`, restart the service. To use a local animated logo, copy it into `/opt/rgnodes-status/public/assets/` and set, for example, `LOGO_URL=/assets/brand.gif`.

## Adding monitors

The public and admin pages include optional, low-volume UI click sounds. They are off by default, can be enabled using the speaker toggle, and create no background audio.

Log into `/admin` using the credentials printed by `ssetup.sh`. Add a monitor by choosing its display category (Service or Server/Node), check method, name, target, location and **Ping interval**. The interval can be set from 5 seconds to 3600 seconds (1 hour) per monitor. The check scheduler runs on the server, so it continues even when the browser is closed.

Supported methods:

- **HTTP/HTTPS:** enter a full URL such as `https://example.com/health`. HTTP status codes 200–399 count as reachable; redirects are followed.
- **TCP port:** enter `tcp://host.example:25565`. This reports whether a TCP connection to the port succeeds.
- **ICMP ping:** enter a hostname or IP such as `8.8.8.8`. The VPS must have a working system `ping` command and its network must permit ICMP echo traffic. Some providers/hosts block ICMP; in that case use HTTP or TCP instead.

Admin can test, edit, pause/resume and delete monitors. Editing a target or method resets that monitor's historical samples; pausing keeps history. A down/up state transition creates an incident. The system does not fabricate successful checks or claim guaranteed zero downtime.

## Uptime and resource use

Availability percentages are calculated from actual recorded check results. New monitors show collection status until there is adequate history. The service keeps recent checks at full detail and compacts older samples into weighted 15-minute buckets during housekeeping. This reduces disk and memory use while preserving weighted uptime accounting. For time windows with less than 80% recorded coverage, the dashboard does not present a misleading percentage.

Monitoring a service from the same VPS where the status website runs cannot report the status website's own host/network outage while that VPS is unreachable. For independent external outage detection, run another monitor outside this VPS.

## Manual run / checks

Requires Node.js 20+:

```bash
npm run check
npm start
```

For manual use, replace the `.env` credential placeholders with a strong `ADMIN_PASSWORD` (at least 24 characters) and `SESSION_SECRET` (at least 64 random characters). Prefer `sudo ./ssetup.sh` for long-running VPS hosting.
