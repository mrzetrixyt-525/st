# RGNODES™ Hosting Status Panel

A production-oriented, dark, animated hosting status website with a separate public dashboard and admin control room. The backend performs real HTTP/HTTPS and TCP checks every 60 seconds by default, stores recorded samples, calculates observed uptime, and tracks outage/recovery incidents.

## Project layout

```text
RGNODES-Status-Panel/
├── database.js          # Atomic JSON storage + append-only check history
├── index.js             # Node.js HTTP API, authentication, monitoring scheduler
├── dashbord/
│   ├── user.html        # Public status dashboard
│   └── admin.html       # Separate admin login + control room
├── public/assets/
│   └── logo.svg         # Replaceable animated brand mark
├── data/                # Persistent JSON/JSONL storage; created/maintained automatically
├── .env                 # Site branding, port, interval, admin credentials (private)
├── .env.example         # Config template
├── package.json
└── ssetup.sh             # Automatic VPS installer + service setup
```

The directory is spelled `dashbord` to match the requested file layout. The public site is `/`; the dedicated admin is `/admin`.

## Automatic VPS install

Upload/extract the ZIP on a Linux VPS with systemd (Ubuntu/Debian/RHEL-family common VPS images), then run:

```bash
chmod +x ssetup.sh
sudo ./ssetup.sh
```

The script copies the project to `/opt/rgnodes-status`, checks Node.js 18+, installs Node.js 22 if needed on supported package-managed systems, creates secure admin credentials and a session secret if the defaults are still present, checks JavaScript syntax, configures storage permissions, registers and enables a systemd unit, and starts the monitor. The service uses `Restart=always` and is enabled at boot. On systems without systemd, it tries a watchdog loop with an `@reboot` cron entry.

At the end, the script prints the URL and admin credentials. Credentials can later be reviewed on the VPS with:

```bash
sudo grep -E '^(ADMIN_USERNAME|ADMIN_PASSWORD)=' /opt/rgnodes-status/.env
```

Useful service commands:

```bash
sudo systemctl status rgnodes-status
sudo journalctl -u rgnodes-status -f
sudo systemctl restart rgnodes-status
```

By default, the site listens on port `3000`. Ensure the VPS firewall permits that port only if you intend to expose it directly, or place Nginx/Caddy in front and use HTTPS. Keep `.env` private; don't commit it or post it publicly. Use HTTPS before exposing the admin login to the internet.

## Branding / animated logo

Edit `/opt/rgnodes-status/.env` and restart the service:

```dotenv
SITE_NAME=RGNODES™ Hosting Status
LOGO_URL=/assets/logo.svg
MONITOR_INTERVAL_SECONDS=60
REQUEST_TIMEOUT_MS=8000
```

To use a local animated GIF or WebP, copy the file under `/opt/rgnodes-status/public/assets/` and set its path, for example `LOGO_URL=/assets/logo.gif`. You can also use an HTTPS logo URL. Browser support applies to the file format, not the status application. Local assets are served from `/assets/`.

## Add real monitored endpoints

Open `/admin` and sign in. Add up to 50 services or server nodes:

- HTTP/HTTPS example: `https://your-domain.example/health`
- TCP example: `tcp://your-node.example:25565`

The backend does not rely on a browser tab being open. It checks enabled monitors after startup and on a 60-second scheduler by default. Admin can test, pause, enable, edit and delete monitors. Pausing retains stored history; changing the URL clears samples for that monitor; deleting removes its history. An outage/recovery incident is recorded when a check result changes state.

**Status semantics:** HTTP `200–399` is treated as up; other responses, connection failures, and timeouts are down. TCP monitors verify a successful connection to the specified host and port; they are not ICMP ping checks. Uptime is calculated from actual saved samples, so newly added monitors show `Collecting` until at least two samples exist. The product does not promise zero downtime or fabricate uptime.

## Security / deployment notes

- Admin login is protected by an HttpOnly, SameSite session cookie and login-attempt rate limiting.
- The session secret and admin password must remain private. The setup script creates strong values on a fresh install.
- Only the API and declared public page/assets are served; `.env`, source files and persisted data are not public static routes.
- The status app can still become unreachable if its own VPS/network fails. For independent outage detection, run a separate monitor outside the infrastructure being checked.
- No npm packages or database server are required. `database.js` uses atomic JSON configuration writes and append-only JSONL check history.

## Manual development start

Requires Node.js 18+:

```bash
npm run check
npm start
```

For a local manual start, first replace `ADMIN_PASSWORD` with a password at least 24 characters long and `SESSION_SECRET` with at least 64 random characters in `.env`. A production VPS should use `ssetup.sh` and HTTPS.
