#!/usr/bin/env bash
set -Eeuo pipefail

# RGNODES™ one-command Linux VPS installer. Installs Node.js when needed,
# generates credentials, prepares storage and enables a restart-on-failure service.
SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${RGNODES_INSTALL_DIR:-/opt/rgnodes-status}"
SERVICE_NAME="rgnodes-status"

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    echo "[RGNODES] Requesting root privileges for service installation..."
    exec sudo -E bash "$SOURCE_DIR/ssetup.sh" "$@"
  fi
  echo "ERROR: run this script as root (example: sudo bash ssetup.sh)." >&2
  exit 1
fi

log() { printf '\n\033[1;35m[RGNODES]\033[0m %s\n' "$*"; }
fail() { printf '\n\033[1;31m[RGNODES ERROR]\033[0m %s\n' "$*" >&2; exit 1; }

log "Preparing the RGNODES™ Hosting Status panel..."
[[ -f "$SOURCE_DIR/index.js" && -f "$SOURCE_DIR/database.js" && -d "$SOURCE_DIR/dashbord" ]] || fail "Required files are missing. Extract the complete ZIP and run ssetup.sh from the project folder."

# Place the persistent installation outside /root or temporary extraction folders.
if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  mkdir -p "$INSTALL_DIR"
  # Update code/assets while preserving secrets and live monitor data on re-runs.
  for item in index.js database.js package.json README.md .env.example .gitignore dashbord public deploy; do
    [[ -e "$SOURCE_DIR/$item" ]] && cp -a "$SOURCE_DIR/$item" "$INSTALL_DIR/"
  done
  if [[ ! -f "$INSTALL_DIR/.env" && -f "$SOURCE_DIR/.env" ]]; then
    cp -a "$SOURCE_DIR/.env" "$INSTALL_DIR/.env"
  fi
  mkdir -p "$INSTALL_DIR/data/history"
  for data_file in targets.json incidents.json; do
    if [[ ! -f "$INSTALL_DIR/data/$data_file" && -f "$SOURCE_DIR/data/$data_file" ]]; then
      cp -a "$SOURCE_DIR/data/$data_file" "$INSTALL_DIR/data/$data_file"
    fi
  done
fi
cd "$INSTALL_DIR"

install_node() {
  if command -v node >/dev/null 2>&1 && node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)' >/dev/null 2>&1; then
    log "Node.js $(node --version) is already installed."
    return
  fi
  log "Installing Node.js 22 LTS because Node.js 20+ is required..."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y ca-certificates curl iputils-ping
    curl -fsSL https://deb.nodesource.com/setup_22.x -o /tmp/rgnodes-nodesource-setup.sh
    bash /tmp/rgnodes-nodesource-setup.sh
    apt-get install -y nodejs
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y ca-certificates curl iputils
    curl -fsSL https://rpm.nodesource.com/setup_22.x -o /tmp/rgnodes-nodesource-setup.sh
    bash /tmp/rgnodes-nodesource-setup.sh
    dnf install -y nodejs
  elif command -v yum >/dev/null 2>&1; then
    yum install -y ca-certificates curl iputils
    curl -fsSL https://rpm.nodesource.com/setup_22.x -o /tmp/rgnodes-nodesource-setup.sh
    bash /tmp/rgnodes-nodesource-setup.sh
    yum install -y nodejs
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache nodejs npm ca-certificates iputils
  else
    fail "Node.js 20+ is required and this OS package manager is not supported. Install Node.js 22 LTS and rerun this script."
  fi
  command -v node >/dev/null 2>&1 || fail "Node.js installation did not complete."
  node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)' || fail "Installed Node.js is too old. Install Node.js 20+ and rerun."
  log "Node.js $(node --version) is ready."
}
install_node

# Install the system ping utility for real ICMP checks; HTTP and TCP remain available if unavailable.
if ! command -v ping >/dev/null 2>&1; then
  log "Installing the ping utility for ICMP monitors..."
  if command -v apt-get >/dev/null 2>&1; then apt-get update -y && apt-get install -y iputils-ping || true
  elif command -v dnf >/dev/null 2>&1; then dnf install -y iputils || true
  elif command -v yum >/dev/null 2>&1; then yum install -y iputils || true
  elif command -v apk >/dev/null 2>&1; then apk add --no-cache iputils || true
  fi
fi
if ! command -v ping >/dev/null 2>&1; then
  log "WARNING: ping utility is not installed. HTTP and TCP monitors will still work; install iputils for ICMP."
fi

# Fill configuration safely; do not overwrite user-provided strong credentials.
[[ -f .env ]] || cp .env.example .env
chmod 600 .env
get_env() { grep -m1 -E "^$1=" .env 2>/dev/null | cut -d= -f2- || true; }
set_env() {
  local key="$1" value="$2" tmp
  tmp="$(mktemp)"
  if grep -q -E "^${key}=" .env; then
    awk -v key="$key" -v value="$value" 'index($0,key "=")==1 {$0=key "=" value; found=1} {print} END {if (!found) print key "=" value}' .env > "$tmp"
  else
    cat .env > "$tmp"
    printf '%s=%s\n' "$key" "$value" >> "$tmp"
  fi
  cat "$tmp" > .env
  rm -f "$tmp"
  chmod 600 .env
}

admin_password="$(get_env ADMIN_PASSWORD)"
if [[ ${#admin_password} -lt 24 || "$admin_password" == SETUP_* || "$admin_password" == replace_* ]]; then
  admin_password="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(36).toString("base64url"))')"
  set_env ADMIN_PASSWORD "$admin_password"
  log "Generated a strong new admin password."
fi
session_secret="$(get_env SESSION_SECRET)"
if [[ ${#session_secret} -lt 64 || "$session_secret" == SETUP_* || "$session_secret" == replace_* ]]; then
  session_secret="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(64).toString("hex"))')"
  set_env SESSION_SECRET "$session_secret"
  log "Generated a new session signing secret."
fi
[[ -n "$(get_env ADMIN_USERNAME)" ]] || set_env ADMIN_USERNAME admin
[[ -n "$(get_env SITE_NAME)" ]] || set_env SITE_NAME 'RGNODES™ Hosting Status'
[[ -n "$(get_env HOST)" ]] || set_env HOST 0.0.0.0
[[ -n "$(get_env PORT)" ]] || set_env PORT 3000

mkdir -p data/history public/assets dashbord
[[ -f data/targets.json ]] || printf '[]\n' > data/targets.json
[[ -f data/incidents.json ]] || printf '[]\n' > data/incidents.json
chmod 750 data data/history public public/assets dashbord
chmod 600 .env data/targets.json data/incidents.json

log "Checking application syntax..."
npm run check

# Prefer systemd for genuine restart-on-crash and start-on-boot support.
if command -v systemctl >/dev/null 2>&1 && { [[ -d /run/systemd/system ]] || systemctl is-system-running >/dev/null 2>&1 || systemctl is-system-running 2>&1 | grep -qE 'starting|degraded'; }; then
  if ! id rgnodes >/dev/null 2>&1; then
    nologin="$(command -v nologin 2>/dev/null || printf '/usr/sbin/nologin')"
    useradd --system --home-dir "$INSTALL_DIR" --shell "$nologin" rgnodes
  fi
  chown -R rgnodes:rgnodes "$INSTALL_DIR"
  chmod 750 "$INSTALL_DIR" "$INSTALL_DIR/data" "$INSTALL_DIR/data/history"
  chmod 600 "$INSTALL_DIR/.env" "$INSTALL_DIR/data/targets.json" "$INSTALL_DIR/data/incidents.json"
  node_path="$(command -v node)"
  cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<UNIT
[Unit]
Description=RGNODES Hosting Status Monitor
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=rgnodes
Group=rgnodes
WorkingDirectory=${INSTALL_DIR}
ExecStart=${node_path} ${INSTALL_DIR}/index.js
Restart=always
RestartSec=3
KillSignal=SIGTERM
TimeoutStopSec=10
Environment=NODE_ENV=production
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
ReadWritePaths=${INSTALL_DIR}/data
UMask=0027
AmbientCapabilities=CAP_NET_RAW
CapabilityBoundingSet=CAP_NET_RAW
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable --now "$SERVICE_NAME"
  sleep 2
  if ! systemctl is-active --quiet "$SERVICE_NAME"; then
    systemctl --no-pager --full status "$SERVICE_NAME" || true
    journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
    fail "The service did not start. See the logs shown above."
  fi
  log "systemd service is enabled and running (automatic restart + boot startup configured)."
else
  log "systemd is unavailable; installing a watchdog + @reboot cron fallback."
  cat > /usr/local/bin/rgnodes-status-supervisor <<SUPERVISOR
#!/usr/bin/env bash
while true; do
  cd '${INSTALL_DIR}'
  '$(command -v node)' '${INSTALL_DIR}/index.js' >> '${INSTALL_DIR}/data/server.log' 2>&1
  sleep 3
done
SUPERVISOR
  chmod 755 /usr/local/bin/rgnodes-status-supervisor
  if ! command -v crontab >/dev/null 2>&1; then
    if command -v apt-get >/dev/null 2>&1; then apt-get install -y cron || true; fi
    if command -v dnf >/dev/null 2>&1; then dnf install -y cronie || true; fi
    if command -v yum >/dev/null 2>&1; then yum install -y cronie || true; fi
  fi
  if command -v crontab >/dev/null 2>&1; then
    (crontab -l 2>/dev/null | grep -v 'rgnodes-status-supervisor' || true; echo '@reboot /usr/local/bin/rgnodes-status-supervisor') | crontab -
    if ! pgrep -f '^/bin/bash /usr/local/bin/rgnodes-status-supervisor$' >/dev/null 2>&1; then nohup /usr/local/bin/rgnodes-status-supervisor >/dev/null 2>&1 & fi
  else
    fail "Neither systemd nor cron is available. Install a process manager to enable 24/7 supervision."
  fi
fi

port="$(get_env PORT)"
port="${port:-2201}"
admin_path="$(get_env ADMIN_PATH)"
admin_path="${admin_path:-/admin}"
health_ok=0
for attempt in {1..15}; do
  if node -e 'fetch(process.argv[1], {signal: AbortSignal.timeout(1500)}).then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))' "http://127.0.0.1:${port}/api/status"; then
    health_ok=1
    break
  fi
  sleep 1
done
if [[ "$health_ok" -ne 1 ]]; then
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --no-pager --full status "$SERVICE_NAME" || true
    journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
  elif [[ -f data/server.log ]]; then
    tail -80 data/server.log || true
  fi
  fail "The service is running or restarting but its API did not pass the local health check. Check the logs above, port, and .env values."
fi
log "Install completed and local API health check passed."
printf '\n  Website:  http://YOUR_VPS_IP:%s/\n  Admin:    http://YOUR_VPS_IP:%s%s\n  Username: %s\n  Password: %s\n  Install:  %s\n\n' "$port" "$port" "$admin_path" "$(get_env ADMIN_USERNAME)" "$(get_env ADMIN_PASSWORD)" "$INSTALL_DIR"
echo "Keep .env private. Configure HTTPS through Nginx/Caddy before using the admin panel on the public internet."
echo "Service logs: journalctl -u ${SERVICE_NAME} -f (systemd)"
