'use strict';

// RGNODES™ Status — dependency-free Node.js status monitor.
// Requires Node.js 20+.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const os = require('node:os');
const { execFile } = require('node:child_process');
const database = require('./database');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const ASSET_DIR = path.join(PUBLIC_DIR, 'assets');
const DATA_DIR = database.DATA_DIR;
const HISTORY_DIR = database.HISTORY_DIR;
const TARGETS_FILE = database.TARGETS_FILE;
const INCIDENTS_FILE = database.INCIDENTS_FILE;
const DASHBOARD_DIR = path.join(ROOT, 'dashbord');
const HISTORY_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_TARGETS = 50;
const MAX_INCIDENTS = 100;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  const raw = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const index = trimmed.indexOf('=');
    if (index < 1) continue;
    const key = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value.replace(/\\n/g, '\n');
  }
}
loadDotEnv(path.join(ROOT, '.env'));

const CONFIG = {
  host: process.env.HOST || '0.0.0.0',
  // 2201 is intentionally separate from an existing Discord bot's port.
  port: clampInt(process.env.PORT, 2201, 1, 65535),
  siteName: cleanText(process.env.SITE_NAME || process.env.STATUS_TITLE || 'RGNODES™ Status', 80),
  companyName: cleanText(process.env.COMPANY_NAME || 'RGNODES™', 80),
  logoUrl: cleanText(process.env.LOGO_URL || '/assets/logo.svg', 500),
  adminPath: (() => { const value = String(process.env.ADMIN_PATH || '/admin').trim().replace(/\/+$/, ''); return /^\/[a-z0-9/_-]+$/i.test(value) && value !== '/' && !value.startsWith('/api') && !value.startsWith('/assets') ? value : '/admin'; })(),
  // Browser refresh is independent from each monitor's Ping (sec) value.
  intervalSeconds: clampInt(process.env.AUTO_REFRESH_SECONDS, 60, 15, 600),
  defaultPingSeconds: clampInt(process.env.DEFAULT_PING_SECONDS, 5, 5, 3600),
  optimizeIntervalSeconds: clampInt(process.env.AUTO_OPTIMIZE_INTERVAL_SECONDS, 60, 15, 3600),
  timeoutMs: clampInt(process.env.REQUEST_TIMEOUT_MS, 8000, 1000, 30000),
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  sessionSecret: process.env.SESSION_SECRET || '',
};
// Compaction turns samples older than 24 hours into weighted 15-minute buckets.
// This keeps 5-second monitoring useful without retaining millions of JSON objects.
const MAX_HISTORY_SAMPLES = 30000;
const RAW_HISTORY_WINDOW_MS = 24 * 60 * 60 * 1000;
const HISTORY_BUCKET_MS = 15 * 60 * 1000;
const MAX_CONCURRENT_CHECKS = clampInt(process.env.MAX_CONCURRENT_CHECKS, 10, 1, 30);

function clampInt(value, fallback, min, max) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed >= min && parsed <= max ? parsed : fallback;
}
function cleanText(value, max = 150) {
  return String(value ?? '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, max);
}
function safeEqualText(a, b) {
  const aa = crypto.createHash('sha256').update(String(a)).digest();
  const bb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(aa, bb);
}
function readJSON(file, fallback) { return database.readJSON(file, fallback); }
function atomicJSON(file, value) { return database.atomicJSON(file, value); }
function makeDirs() {
  for (const dir of [PUBLIC_DIR, ASSET_DIR, DASHBOARD_DIR]) fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
  database.initialize();
}
makeDirs();

if (!CONFIG.adminPassword || CONFIG.adminPassword.length < 12 || !CONFIG.sessionSecret || CONFIG.sessionSecret.length < 32) {
  console.error('\n[RGNODES] SECURITY CONFIGURATION ERROR');
  console.error('Set ADMIN_PASSWORD (12+ characters) and SESSION_SECRET (32+ characters) in .env.');
  console.error('Tip: run ./ssetup.sh to generate secure initial values.\n');
  process.exit(1);
}

let targets = readJSON(TARGETS_FILE, []);
if (!Array.isArray(targets)) targets = [];
targets = targets.filter((t) => t && typeof t.id === 'string' && typeof t.name === 'string' && typeof t.url === 'string').slice(0, MAX_TARGETS).map((t) => {
  const inferredType = String(t.url).toLowerCase().startsWith('tcp://') ? 'tcp' : (String(t.url).toLowerCase().startsWith('icmp://') ? 'icmp' : 'http');
  return {
    id: t.id,
    name: cleanText(t.name, 80) || 'Unnamed monitor',
    category: t.category === 'server' ? 'server' : 'service',
    type: ['http', 'tcp', 'icmp'].includes(t.type) ? t.type : inferredType,
    intervalSeconds: clampInt(t.intervalSeconds, CONFIG.defaultPingSeconds, 5, 3600),
    location: cleanText(t.location || '', 100),
    url: cleanText(t.url, 500),
    enabled: t.enabled !== false,
    createdAt: Number(t.createdAt) || Date.now(),
  };
});
atomicJSON(TARGETS_FILE, targets);
let incidents = readJSON(INCIDENTS_FILE, []);
if (!Array.isArray(incidents)) incidents = [];
incidents = incidents.slice(0, MAX_INCIDENTS);

const states = new Map();
const nextCheckAt = new Map();
const targetChecksInFlight = new Set();
const sessions = new Map();
const loginAttempts = new Map();
let checksRunning = false;
let lastChecksCompletedAt = null;

function loadHistory(id) { return database.loadHistory(id, HISTORY_RETENTION_MS, MAX_HISTORY_SAMPLES); }
function ensureState(target) {
  if (!states.has(target.id)) {
    const history = loadHistory(target.id);
    const last = history[history.length - 1];
    states.set(target.id, {
      history,
      status: last?.status || 'unknown',
      latencyMs: last?.latencyMs ?? null,
      lastCheck: last?.at ?? null,
      lastError: last?.error || '',
    });
  }
  return states.get(target.id);
}
for (const target of targets) ensureState(target);

function uptimeStats(history, windowMs, intervalSeconds) {
  const now = Date.now();
  const cutoff = now - windowMs;
  let checks = 0;
  let successes = 0;
  for (let i = history.length - 1; i >= 0; i -= 1) {
    const sample = history[i];
    const sampleEnd = Number(sample.periodEnd || sample.at || 0);
    if (sampleEnd < cutoff) continue;
    const weight = Math.max(1, Number(sample.samples) || 1);
    checks += weight;
    successes += Number.isFinite(Number(sample.successes)) && sample.samples
      ? Math.max(0, Math.min(weight, Number(sample.successes)))
      : (sample.status === 'up' ? 1 : 0);
  }
  const expected = Math.max(1, Math.floor(windowMs / (Math.max(5, Number(intervalSeconds) || CONFIG.defaultPingSeconds) * 1000)));
  const coveragePercent = Number(Math.min(100, (checks / expected) * 100).toFixed(1));
  // Never label a thin slice of old data as a full-window uptime figure.
  return {
    percent: checks >= 2 && coveragePercent >= 80 ? Number(((successes / checks) * 100).toFixed(2)) : null,
    checks,
    coveragePercent,
  };
}
function publicTarget(target) {
  const state = ensureState(target);
  const history = state.history;
  return {
    id: target.id,
    name: target.name,
    category: target.category,
    type: target.type || 'http',
    intervalSeconds: target.intervalSeconds || CONFIG.defaultPingSeconds,
    location: target.location,
    url: target.url,
    enabled: target.enabled,
    status: target.enabled ? state.status : 'paused',
    latencyMs: state.latencyMs,
    lastCheck: state.lastCheck,
    lastError: state.lastError,
    uptime24h: uptimeStats(history, 24 * 60 * 60 * 1000, target.intervalSeconds),
    uptime7d: uptimeStats(history, 7 * 24 * 60 * 60 * 1000, target.intervalSeconds),
    uptime30d: uptimeStats(history, HISTORY_RETENTION_MS, target.intervalSeconds),
    history: history.slice(-30).map((sample) => sample.status),
  };
}
function calculateSummary(publicTargets) {
  const enabled = publicTargets.filter((t) => t.enabled);
  const servers = enabled.filter((t) => t.category === 'server');
  const services = enabled.filter((t) => t.category === 'service');
  const countUp = (list) => list.filter((t) => t.status === 'up').length;
  const countDown = (list) => list.filter((t) => t.status === 'down').length;
  let status = 'awaiting';
  if (enabled.length) {
    if (enabled.some((t) => t.status === 'unknown')) status = 'checking';
    else if (countDown(enabled) === enabled.length) status = 'outage';
    else if (countDown(enabled) > 0) status = 'degraded';
    else status = 'operational';
  }
  return {
    status,
    total: enabled.length,
    online: countUp(enabled),
    down: countDown(enabled),
    serversTotal: servers.length,
    serversOnline: countUp(servers),
    servicesTotal: services.length,
    servicesOnline: countUp(services),
  };
}

function addIncident(target, type, message) {
  incidents.unshift({
    id: crypto.randomUUID(),
    targetId: target.id,
    targetName: target.name,
    category: target.category,
    type,
    message: cleanText(message, 220),
    at: Date.now(),
  });
  incidents = incidents.slice(0, MAX_INCIDENTS);
  atomicJSON(INCIDENTS_FILE, incidents);
}

function tcpCheck(urlValue) {
  return new Promise((resolve) => {
    let url;
    try { url = new URL(urlValue); } catch { resolve({ status: 'down', latencyMs: null, error: 'Invalid TCP endpoint' }); return; }
    const port = Number(url.port);
    const host = url.hostname;
    if (!host || !Number.isInteger(port) || port < 1 || port > 65535) {
      resolve({ status: 'down', latencyMs: null, error: 'TCP endpoint must use tcp://hostname:port' });
      return;
    }
    const started = Date.now();
    let settled = false;
    const socket = net.createConnection({ host, port });
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve({ status: 'down', latencyMs: null, error: `Connection timed out after ${CONFIG.timeoutMs} ms` });
    }, CONFIG.timeoutMs);
    socket.once('connect', () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const latencyMs = Date.now() - started;
      socket.destroy();
      resolve({ status: 'up', latencyMs, error: '' });
    });
    socket.once('error', (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.destroy();
      resolve({ status: 'down', latencyMs: null, error: cleanText(error.code || error.message || 'TCP connection failed', 180) });
    });
  });
}
function icmpCheck(urlValue) {
  return new Promise((resolve) => {
    let parsed;
    try { parsed = new URL(urlValue); } catch { resolve({ status: 'down', latencyMs: null, error: 'Invalid ICMP ping target' }); return; }
    const host = parsed.hostname;
    if (!host || /[\s/\\]/.test(host)) { resolve({ status: 'down', latencyMs: null, error: 'ICMP target must be a hostname or IP address' }); return; }
    const seconds = Math.max(1, Math.ceil(CONFIG.timeoutMs / 1000));
    const args = process.platform === 'win32'
      ? ['-n', '1', '-w', String(CONFIG.timeoutMs), host]
      : [...(host.includes(':') ? ['-6'] : []), '-n', '-c', '1', '-W', String(seconds), host];
    const started = Date.now();
    execFile('ping', args, { timeout: CONFIG.timeoutMs + 1500, maxBuffer: 16 * 1024, windowsHide: true }, (error, stdout, stderr) => {
      const output = `${stdout || ''}\n${stderr || ''}`;
      if (!error) {
        const match = output.match(/time[=<]\s*([\d.]+)\s*ms/i);
        return resolve({ status: 'up', latencyMs: match ? Number(match[1]) : Date.now() - started, error: '' });
      }
      const message = error.code === 'ENOENT'
        ? 'The system ping command is unavailable on this VPS'
        : (error.killed ? `Ping timed out after ${CONFIG.timeoutMs} ms` : cleanText(output.match(/(?:100% packet loss|Destination host unreachable|Name or service not known|Temporary failure in name resolution|Network is unreachable|Operation not permitted)/i)?.[0] || error.code || 'ICMP request failed', 180));
      resolve({ status: 'down', latencyMs: null, error: message });
    });
  });
}
async function performCheck(target) {
  const type = target.type || (target.url.toLowerCase().startsWith('tcp://') ? 'tcp' : (target.url.toLowerCase().startsWith('icmp://') ? 'icmp' : 'http'));
  if (type === 'tcp') return tcpCheck(target.url);
  if (type === 'icmp') return icmpCheck(target.url);
  const started = Date.now();
  try {
    const response = await fetch(target.url, {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'User-Agent': 'RGNODES-Status-Monitor/2.0 (+health check)',
        'Accept': '*/*',
        'Range': 'bytes=0-0',
        'Cache-Control': 'no-cache',
      },
      signal: AbortSignal.timeout(CONFIG.timeoutMs),
    });
    const latencyMs = Date.now() - started;
    const code = response.status;
    if (response.body) response.body.cancel().catch(() => {});
    if (code >= 200 && code < 400) return { status: 'up', latencyMs, error: '' };
    return { status: 'down', latencyMs, error: `HTTP ${code}` };
  } catch (error) {
    const timeout = error?.name === 'TimeoutError' || error?.name === 'AbortError';
    return {
      status: 'down', latencyMs: null,
      error: cleanText(timeout ? `Request timed out after ${CONFIG.timeoutMs} ms` : (error?.cause?.code || error?.code || error?.message || 'Request failed'), 180),
    };
  }
}
async function checkTarget(target) {
  if (!target || !target.enabled || targetChecksInFlight.has(target.id)) return false;
  const checkedUrl = target.url;
  const state = ensureState(target);
  const oldStatus = state.status;
  targetChecksInFlight.add(target.id);
  checksRunning = true;
  try {
    const result = await performCheck(target);
    // Ignore late results if an administrator has edited, paused, or deleted this endpoint meanwhile.
    const currentTarget = targets.find((item) => item.id === target.id);
    if (!currentTarget || !currentTarget.enabled || currentTarget.url !== checkedUrl || states.get(target.id) !== state) return false;
    const sample = { at: Date.now(), status: result.status, latencyMs: result.latencyMs, error: cleanText(result.error || '', 180) };
    state.status = sample.status;
    state.latencyMs = sample.latencyMs;
    state.lastCheck = sample.at;
    state.lastError = sample.error;
    state.history.push(sample);
    if (state.history.length > MAX_HISTORY_SAMPLES) state.history.splice(0, state.history.length - MAX_HISTORY_SAMPLES);
    try { database.appendHistory(target.id, sample); }
    catch (error) { console.error(`[RGNODES] History write failed for ${currentTarget.name}: ${error.message}`); }
    if (sample.status === 'down' && oldStatus !== 'down') addIncident(currentTarget, 'outage', `${currentTarget.name} is unreachable (${sample.error || 'health check failed'}).`);
    if (sample.status === 'up' && oldStatus === 'down') addIncident(currentTarget, 'resolved', `${currentTarget.name} recovered and is responding again.`);
    lastChecksCompletedAt = sample.at;
    return true;
  } finally {
    targetChecksInFlight.delete(target.id);
    const current = targets.find((item) => item.id === target.id);
    if (current && current.enabled) {
      nextCheckAt.set(current.id, Date.now() + Math.max(5, current.intervalSeconds || CONFIG.defaultPingSeconds) * 1000);
    } else {
      nextCheckAt.delete(target.id);
    }
    checksRunning = targetChecksInFlight.size > 0;
  }
}
async function runChecks(targetIds = null) {
  const selected = targets.filter((target) => target.enabled && (!targetIds || targetIds.includes(target.id)));
  if (!selected.length) { lastChecksCompletedAt = Date.now(); return; }
  // Fixed worker count keeps failed endpoints from overwhelming smaller VPS instances.
  checksRunning = true;
  let next = 0;
  const workers = Array.from({ length: Math.min(MAX_CONCURRENT_CHECKS, selected.length) }, async () => {
    while (next < selected.length) {
      const index = next++;
      try { await checkTarget(selected[index]); }
      catch (error) { console.error(`[RGNODES] Check failed for ${selected[index].name}: ${error.message}`); }
    }
  });
  try { await Promise.all(workers); }
  finally { checksRunning = false; lastChecksCompletedAt = Date.now(); }
}

function parseCookies(req) {
  const out = {};
  for (const chunk of String(req.headers.cookie || '').split(';')) {
    const index = chunk.indexOf('=');
    if (index > 0) {
      try { out[chunk.slice(0, index).trim()] = decodeURIComponent(chunk.slice(index + 1).trim()); } catch { /* Ignore malformed cookies. */ }
    }
  }
  return out;
}
function requestIP(req) { return req.socket.remoteAddress || 'unknown'; }
function signSession(sessionId) { return crypto.createHmac('sha256', CONFIG.sessionSecret).update(sessionId).digest('base64url'); }
function sessionIdFromRequest(req) {
  const token = parseCookies(req).rgnodes_session;
  if (!token) return null;
  const dot = token.lastIndexOf('.');
  if (dot < 1) return null;
  const sessionId = token.slice(0, dot);
  const supplied = Buffer.from(token.slice(dot + 1));
  const expected = Buffer.from(signSession(sessionId));
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) return null;
  return sessionId;
}
function validSession(req) {
  const sessionId = sessionIdFromRequest(req);
  if (!sessionId) return false;
  const session = sessions.get(sessionId);
  if (!session || session.expiresAt < Date.now()) { sessions.delete(sessionId); return false; }
  return true;
}
function authRequired(req, res) {
  if (validSession(req)) return true;
  sendJSON(res, 401, { error: 'Admin login required.' });
  return false;
}
function sendJSON(res, status, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Length': Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(body);
}
function readBody(req, maxBytes = 32768) {
  return new Promise((resolve, reject) => {
    let raw = '';
    let total = 0;
    req.setEncoding('utf8');
    req.on('data', (chunk) => {
      total += Buffer.byteLength(chunk);
      if (total > maxBytes) { reject(Object.assign(new Error('Request body too large.'), { statusCode: 413 })); req.destroy(); return; }
      raw += chunk;
    });
    req.on('end', () => {
      if (!raw.trim()) { resolve({}); return; }
      try { resolve(JSON.parse(raw)); } catch { reject(Object.assign(new Error('Invalid JSON body.'), { statusCode: 400 })); }
    });
    req.on('error', reject);
  });
}
function validateTarget(input) {
  const name = cleanText(input?.name, 80);
  const rawUrl = cleanText(input?.url, 500);
  const category = input?.category === 'server' ? 'server' : (input?.category === 'service' ? 'service' : '');
  const location = cleanText(input?.location || '', 100);
  let type = ['http', 'tcp', 'icmp'].includes(input?.type) ? input.type : '';
  if (!type) type = /^tcp:\/\//i.test(rawUrl) ? 'tcp' : (/^icmp:\/\//i.test(rawUrl) ? 'icmp' : 'http');
  const intervalSeconds = clampInt(input?.intervalSeconds, CONFIG.defaultPingSeconds, 5, 3600);
  if (name.length < 2) throw Object.assign(new Error('Name must contain at least 2 characters.'), { statusCode: 400 });
  if (!category) throw Object.assign(new Error('Choose Server or Service.'), { statusCode: 400 });
  let parsed;
  try {
    if (type === 'icmp' && !/^[a-z][a-z\d+.-]*:\/\//i.test(rawUrl)) parsed = new URL(`icmp://${rawUrl}`);
    else parsed = new URL(rawUrl);
  } catch { throw Object.assign(new Error('Enter a valid HTTP(S) URL, tcp://host:port, or hostname/IP for ICMP.'), { statusCode: 400 }); }
  if (parsed.username || parsed.password) throw Object.assign(new Error('Do not embed credentials in monitor URLs.'), { statusCode: 400 });
  let url;
  if (type === 'http') {
    if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname) throw Object.assign(new Error('HTTP monitor needs a valid http:// or https:// URL.'), { statusCode: 400 });
    url = parsed.toString();
  } else if (type === 'tcp') {
    if (parsed.protocol !== 'tcp:' || !parsed.hostname || !parsed.port || Number(parsed.port) < 1 || Number(parsed.port) > 65535) {
      throw Object.assign(new Error('TCP monitors must look like tcp://hostname:25565.'), { statusCode: 400 });
    }
    url = `tcp://${parsed.hostname}:${parsed.port}`;
  } else {
    if (!parsed.hostname || !['icmp:', 'ping:'].includes(parsed.protocol) || parsed.pathname !== '/' && parsed.pathname !== '') {
      throw Object.assign(new Error('ICMP target must be a hostname or IP address without a path.'), { statusCode: 400 });
    }
    url = `icmp://${parsed.hostname}`;
  }
  return { name, url, type, category, location, intervalSeconds, enabled: input?.enabled !== false };
}
function setSessionCookie(req, res, token, maxAge) {
  const forwardedSecure = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https';
  const secure = Boolean(req.socket.encrypted || forwardedSecure);
  res.setHeader('Set-Cookie', `rgnodes_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure ? '; Secure' : ''}`);
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.ico': 'image/x-icon', '.avif': 'image/avif',
};
function staticFile(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return sendJSON(res, 405, { error: 'Method not allowed.' }, { Allow: 'GET, HEAD' });
  let file;
  if (pathname === '/' || pathname === '/index.html' || pathname === '/user' || pathname === '/user.html' || pathname === '/dashbord/user.html') file = path.join(DASHBOARD_DIR, 'user.html');
  else if (pathname === CONFIG.adminPath || pathname === `${CONFIG.adminPath}.html` || pathname === '/admin.html' || pathname === '/dashbord/admin.html') file = path.join(DASHBOARD_DIR, 'admin.html');
  else if (pathname === '/assets' || pathname.startsWith('/assets/')) {
    let decoded;
    try { decoded = decodeURIComponent(pathname.slice('/assets/'.length)); } catch { return sendJSON(res, 400, { error: 'Bad path.' }); }
    if (!decoded || decoded.includes('\0') || decoded.split(/[\\/]/).some((part) => part === '..' || part.startsWith('.'))) return sendJSON(res, 404, { error: 'Not found.' });
    file = path.resolve(ASSET_DIR, decoded);
    if (!file.startsWith(`${ASSET_DIR}${path.sep}`)) return sendJSON(res, 404, { error: 'Not found.' });
  } else return sendJSON(res, 404, { error: 'Not found.' });
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return sendJSON(res, 404, { error: 'Asset not found.' });
  const ext = path.extname(file).toLowerCase();
  const contentType = MIME[ext];
  if (!contentType) return sendJSON(res, 415, { error: 'Unsupported asset type.' });
  const headers = {
    'Content-Type': contentType,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    'X-Frame-Options': 'DENY',
  };
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

async function handleAPI(req, res, url) {
  const pathname = url.pathname;
  if (req.method === 'GET' && pathname === '/api/config') {
    return sendJSON(res, 200, {
      siteName: CONFIG.siteName,
      companyName: CONFIG.companyName,
      logoUrl: CONFIG.logoUrl,
      intervalSeconds: CONFIG.intervalSeconds,
      autoRefreshSeconds: CONFIG.intervalSeconds,
      defaultPingSeconds: CONFIG.defaultPingSeconds,
      optimizeIntervalSeconds: CONFIG.optimizeIntervalSeconds,
      timeoutMs: CONFIG.timeoutMs,
      adminPath: CONFIG.adminPath,
      developerName: 'Mr.Zetnix',
      serverTime: Date.now(),
    });
  }
  if (req.method === 'GET' && pathname === '/api/status') {
    const view = targets.map(publicTarget);
    return sendJSON(res, 200, {
      generatedAt: Date.now(),
      intervalSeconds: CONFIG.intervalSeconds,
      checkRunning: checksRunning,
      lastChecksCompletedAt,
      summary: calculateSummary(view),
      targets: view,
      incidents: incidents.slice(0, 30),
    });
  }
  if (req.method === 'POST' && pathname === '/api/admin/login') {
    const ip = requestIP(req);
    const now = Date.now();
    let attempts = loginAttempts.get(ip);
    if (!attempts || attempts.resetAt <= now) attempts = { count: 0, resetAt: now + LOGIN_WINDOW_MS };
    if (attempts.count >= MAX_LOGIN_ATTEMPTS) return sendJSON(res, 429, { error: 'Too many login attempts. Try again in 15 minutes.' }, { 'Retry-After': String(Math.ceil((attempts.resetAt - now) / 1000)) });
    const body = await readBody(req);
    const usernameOk = safeEqualText(body.username || '', CONFIG.adminUsername);
    const passwordOk = safeEqualText(body.password || '', CONFIG.adminPassword);
    if (!usernameOk || !passwordOk) {
      attempts.count += 1;
      loginAttempts.set(ip, attempts);
      return sendJSON(res, 401, { error: 'Incorrect username or password.' });
    }
    loginAttempts.delete(ip);
    for (const [key, value] of sessions) if (value.expiresAt < now) sessions.delete(key);
    const sessionId = crypto.randomBytes(32).toString('base64url');
    sessions.set(sessionId, { username: CONFIG.adminUsername, expiresAt: now + 12 * 60 * 60 * 1000 });
    setSessionCookie(req, res, `${sessionId}.${signSession(sessionId)}`, 12 * 60 * 60);
    return sendJSON(res, 200, { ok: true, username: CONFIG.adminUsername });
  }
  if (req.method === 'POST' && pathname === '/api/admin/logout') {
    const sessionId = sessionIdFromRequest(req);
    if (sessionId) sessions.delete(sessionId);
    setSessionCookie(req, res, '', 0);
    return sendJSON(res, 200, { ok: true });
  }
  if (pathname.startsWith('/api/admin/')) {
    if (!authRequired(req, res)) return;
    if (req.method === 'GET' && pathname === '/api/admin/me') return sendJSON(res, 200, { ok: true, username: CONFIG.adminUsername });
    if (req.method === 'POST' && pathname === '/api/admin/targets') {
      const body = await readBody(req);
      if (targets.length >= MAX_TARGETS) return sendJSON(res, 400, { error: `A maximum of ${MAX_TARGETS} monitors is supported.` });
      const fields = validateTarget(body);
      const target = { id: crypto.randomUUID(), ...fields, createdAt: Date.now() };
      targets.push(target);
      ensureState(target);
      nextCheckAt.set(target.id, 0);
      atomicJSON(TARGETS_FILE, targets);
      if (target.enabled) await checkTarget(target);
      return sendJSON(res, 201, { ok: true, target: publicTarget(target) });
    }
    const checkMatch = pathname.match(/^\/api\/admin\/targets\/([a-f0-9-]{36})\/check$/i);
    if (req.method === 'POST' && checkMatch) {
      const target = targets.find((item) => item.id === checkMatch[1]);
      if (!target) return sendJSON(res, 404, { error: 'Monitor not found.' });
      if (!target.enabled) return sendJSON(res, 400, { error: 'Enable this monitor before checking it.' });
      await checkTarget(target);
      return sendJSON(res, 200, { ok: true, target: publicTarget(target) });
    }
    const targetMatch = pathname.match(/^\/api\/admin\/targets\/([a-f0-9-]{36})$/i);
    if (targetMatch && req.method === 'PUT') {
      const index = targets.findIndex((item) => item.id === targetMatch[1]);
      if (index < 0) return sendJSON(res, 404, { error: 'Monitor not found.' });
      const body = await readBody(req);
      const fields = validateTarget(body);
      const oldTarget = targets[index];
      const updated = { ...oldTarget, ...fields, id: oldTarget.id };
      targets[index] = updated;
      if (oldTarget.url !== updated.url || oldTarget.type !== updated.type) {
        states.set(updated.id, { history: [], status: 'unknown', latencyMs: null, lastCheck: null, lastError: '' });
        try { database.saveHistory(updated.id, []); } catch (error) { console.error(`[RGNODES] Could not reset history: ${error.message}`); }
      }
      atomicJSON(TARGETS_FILE, targets);
      nextCheckAt.set(updated.id, 0);
      if (updated.enabled) await checkTarget(updated);
      return sendJSON(res, 200, { ok: true, target: publicTarget(updated) });
    }
    if (targetMatch && req.method === 'DELETE') {
      const index = targets.findIndex((item) => item.id === targetMatch[1]);
      if (index < 0) return sendJSON(res, 404, { error: 'Monitor not found.' });
      const [removed] = targets.splice(index, 1);
      states.delete(removed.id);
      nextCheckAt.delete(removed.id);
      try { database.deleteHistory(removed.id); } catch (error) { console.error(`[RGNODES] Could not delete history: ${error.message}`); }
      atomicJSON(TARGETS_FILE, targets);
      return sendJSON(res, 200, { ok: true });
    }
    return sendJSON(res, 404, { error: 'Admin endpoint not found.' });
  }
  return sendJSON(res, 404, { error: 'API endpoint not found.' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await handleAPI(req, res, url);
    return staticFile(req, res, decodeURIComponent(url.pathname));
  } catch (error) {
    if (res.headersSent) { res.destroy(); return; }
    const code = Number(error.statusCode) || 500;
    if (code >= 500) console.error(`[RGNODES] ${error.stack || error.message}`);
    return sendJSON(res, code, { error: code >= 500 ? 'Unexpected server error.' : cleanText(error.message, 180) });
  }
});
server.requestTimeout = 30000;
server.headersTimeout = 10000;
server.keepAliveTimeout = 5000;

let monitorTimer = null;
let optimizeTimer = null;
async function monitorLoop() {
  const now = Date.now();
  let availableSlots = Math.max(0, MAX_CONCURRENT_CHECKS - targetChecksInFlight.size);
  for (const target of targets) {
    if (!target.enabled || targetChecksInFlight.has(target.id) || availableSlots <= 0) continue;
    const dueAt = nextCheckAt.get(target.id) ?? 0;
    if (dueAt > now) continue;
    // Schedule from the start time so a target does not overlap its own interval.
    nextCheckAt.set(target.id, now + Math.max(5, target.intervalSeconds || CONFIG.defaultPingSeconds) * 1000);
    availableSlots -= 1;
    void checkTarget(target).catch((error) => {
      console.error(`[RGNODES] Monitor loop error for ${target.name}: ${error.message}`);
    });
  }
  checksRunning = targetChecksInFlight.size > 0;
}
function optimizeStorage() {
  const now = Date.now();
  const retentionCutoff = now - HISTORY_RETENTION_MS;
  const rawCutoff = now - RAW_HISTORY_WINDOW_MS;
  for (const target of targets) {
    const state = states.get(target.id);
    if (!state || !state.history.length) continue;
    const groups = new Map();
    const recent = [];
    let changed = false;
    for (const sample of state.history) {
      const startAt = Number(sample.periodStart ?? sample.at);
      const endAt = Number(sample.periodEnd ?? sample.at);
      if (!Number.isFinite(endAt) || endAt < retentionCutoff) { changed = true; continue; }
      if (endAt >= rawCutoff) { recent.push(sample); continue; }
      changed = true;
      const bucketStart = Math.floor(startAt / HISTORY_BUCKET_MS) * HISTORY_BUCKET_MS;
      const bucketEnd = bucketStart + HISTORY_BUCKET_MS;
      const bucket = groups.get(bucketStart) || { periodStart: bucketStart, periodEnd: bucketEnd, samples: 0, successes: 0, failures: 0, latencySum: 0, latencyCount: 0, lastError: '' };
      const count = Math.max(1, Number(sample.samples) || 1);
      const successes = Number.isFinite(Number(sample.successes)) && sample.samples
        ? Math.max(0, Math.min(count, Number(sample.successes)))
        : (sample.status === 'up' ? 1 : 0);
      const failures = Math.max(0, count - successes);
      bucket.samples += count;
      bucket.successes += successes;
      bucket.failures += failures;
      if (Number.isFinite(sample.latencyMs)) { bucket.latencySum += sample.latencyMs * count; bucket.latencyCount += count; }
      if (sample.error) bucket.lastError = sample.error;
      groups.set(bucketStart, bucket);
    }
    if (!changed) continue;
    const compacted = [...groups.values()].map((bucket) => ({
      at: Math.min(bucket.periodEnd, now), periodStart: bucket.periodStart, periodEnd: Math.min(bucket.periodEnd, now),
      status: bucket.failures > 0 ? 'down' : 'up', samples: bucket.samples,
      successes: bucket.successes, failures: bucket.failures,
      latencyMs: bucket.latencyCount ? Number((bucket.latencySum / bucket.latencyCount).toFixed(2)) : null,
      error: bucket.failures ? bucket.lastError : '',
    }));
    state.history = [...compacted, ...recent].sort((a, b) => a.at - b.at).slice(-MAX_HISTORY_SAMPLES);
    try { database.saveHistory(target.id, state.history); }
    catch (error) { console.error(`[RGNODES] History compaction failed for ${target.name}: ${error.message}`); }
  }
  const keepIncidents = incidents.filter((item) => Number(item.at) >= retentionCutoff).slice(0, MAX_INCIDENTS);
  if (keepIncidents.length !== incidents.length) { incidents = keepIncidents; atomicJSON(INCIDENTS_FILE, incidents); }
  const nowForMaps = Date.now();
  for (const [key, value] of loginAttempts) if (value.resetAt <= nowForMaps) loginAttempts.delete(key);
  for (const [key, value] of sessions) if (value.expiresAt <= nowForMaps) sessions.delete(key);
}

server.listen(CONFIG.port, CONFIG.host, () => {
  console.log('');
  console.log('  ██████╗  ██████╗ ███╗   ██╗ ██████╗ ██████╗ ███████╗███████╗');
  const cyan = '\x1b[36m', green = '\x1b[32m', violet = '\x1b[35m', reset = '\x1b[0m';
  console.log(`${green}[INFO]${reset} The RGNODES™ Status Page is live ♥`);
  console.log(`  ${cyan}Public:${reset} http://localhost:${CONFIG.port}/`);
  console.log(`  ${violet}Admin:${reset}  http://localhost:${CONFIG.port}${CONFIG.adminPath}`);
  const detected = Object.values(os.networkInterfaces()).flat().filter((item) => item && item.family === 'IPv4' && !item.internal).map((item) => item.address);
  for (const address of [...new Set(detected)].slice(0, 8)) {
    console.log(`  ${cyan}Detected LAN/VPS address:${reset} http://${address}:${CONFIG.port}/`);
  }
  if (!detected.length) console.log(`  ${cyan}Listen:${reset} ${CONFIG.host}:${CONFIG.port}`);
  console.log(`  ${green}[INFO]${reset} Refresh ${CONFIG.intervalSeconds}s · default ping ${CONFIG.defaultPingSeconds}s · timeout ${CONFIG.timeoutMs}ms`);
  console.log(`  ${green}[INFO]${reset} Auto optimize every ${CONFIG.optimizeIntervalSeconds}s · monitors ${targets.length}/${MAX_TARGETS}`);
  console.log('  Developer: Mr.Zetnix · credentials are stored privately in .env');
  console.log('');
  void monitorLoop();
  monitorTimer = setInterval(() => { void monitorLoop(); }, 1000);
  monitorTimer.unref();
  optimizeTimer = setInterval(optimizeStorage, CONFIG.optimizeIntervalSeconds * 1000);
  optimizeTimer.unref();
});

function shutdown(signal) {
  console.log(`\n[RGNODES] ${signal} received; stopping cleanly...`);
  if (monitorTimer) clearInterval(monitorTimer);
  if (optimizeTimer) clearInterval(optimizeTimer);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
