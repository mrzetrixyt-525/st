'use strict';

// Small, dependency-free persistent storage layer. All writes are atomic or append-only.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const HISTORY_DIR = path.join(DATA_DIR, 'history');
const TARGETS_FILE = path.join(DATA_DIR, 'targets.json');
const INCIDENTS_FILE = path.join(DATA_DIR, 'incidents.json');

function initialize() {
  for (const dir of [DATA_DIR, HISTORY_DIR]) fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
  if (!fs.existsSync(TARGETS_FILE)) atomicJSON(TARGETS_FILE, []);
  if (!fs.existsSync(INCIDENTS_FILE)) atomicJSON(INCIDENTS_FILE, []);
}

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (error) {
    if (error.code !== 'ENOENT') console.error(`[RGNODES] Storage read warning (${path.basename(file)}): ${error.message}`);
    return fallback;
  }
}

function atomicJSON(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o750 });
  const temporary = `${file}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, file);
    try { fs.chmodSync(file, 0o600); } catch {}
  } finally {
    try { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); } catch {}
  }
}

function historyFile(id) {
  if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/i.test(id)) throw new Error('Invalid monitor ID');
  return path.join(HISTORY_DIR, `${id}.jsonl`);
}

function loadHistory(id, retentionMs, maxSamples) {
  const file = historyFile(id);
  if (!fs.existsSync(file)) return [];
  const cutoff = Date.now() - retentionMs;
  let rows = [];
  try {
    rows = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean).flatMap((line) => {
      try {
        const row = JSON.parse(line);
        const at = Number(row.at);
        const periodStart = Number(row.periodStart);
        const periodEnd = Number(row.periodEnd);
        if (at >= cutoff && ['up', 'down'].includes(row.status)) {
          const compacted = Number.isFinite(periodStart) && Number.isFinite(periodEnd) && Number(row.samples) >= 1;
          const latency = row.latencyMs === null || row.latencyMs === undefined ? null : Number(row.latencyMs);
          return [{
            at,
            status: row.status,
            latencyMs: Number.isFinite(latency) ? latency : null,
            error: String(row.error || '').slice(0, 180),
            ...(compacted ? {
              periodStart, periodEnd,
              samples: Math.max(1, Number(row.samples) || 1),
              successes: Math.max(0, Number(row.successes) || 0),
              failures: Math.max(0, Number(row.failures) || 0),
            } : {}),
          }];
        }
      } catch { /* Ignore only the corrupted row; preserve the rest of the history. */ }
      return [];
    }).slice(-maxSamples);
  } catch (error) {
    console.error(`[RGNODES] History read warning (${id}): ${error.message}`);
  }
  saveHistory(id, rows);
  return rows;
}

function appendHistory(id, sample) {
  const file = historyFile(id);
  fs.mkdirSync(HISTORY_DIR, { recursive: true, mode: 0o750 });
  fs.appendFileSync(file, `${JSON.stringify(sample)}\n`, { mode: 0o600 });
  try { fs.chmodSync(file, 0o600); } catch {}
}

function saveHistory(id, rows) {
  const file = historyFile(id);
  const content = rows.map((row) => JSON.stringify(row)).join('\n');
  const temporary = `${file}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(temporary, content ? `${content}\n` : '', { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, file);
    try { fs.chmodSync(file, 0o600); } catch {}
  } finally {
    try { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); } catch {}
  }
}

function deleteHistory(id) {
  try { fs.unlinkSync(historyFile(id)); } catch (error) { if (error.code !== 'ENOENT') throw error; }
}

module.exports = {
  ROOT, DATA_DIR, HISTORY_DIR, TARGETS_FILE, INCIDENTS_FILE,
  initialize, readJSON, atomicJSON, historyFile, loadHistory,
  appendHistory, saveHistory, deleteHistory,
};
